package test3;

@Anno6(str2={})
public class AnnoTest6 {
    int foo() { return 1; }
}
