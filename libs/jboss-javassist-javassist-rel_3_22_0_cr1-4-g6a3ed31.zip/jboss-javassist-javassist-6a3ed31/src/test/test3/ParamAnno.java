package test3;

public class ParamAnno {
    public int foo(int i, String s, ParamAnno pa, double d) {
        return i + 1;
    }

    public void bar() {} 
}
